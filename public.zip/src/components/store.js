// import {create} from "zustand"

// const useStore = create((set)=>({
// updatedDetails:{},
// updateDetails:(details)=> set(state=>({updatedDetails:{...details}}))
// }))

